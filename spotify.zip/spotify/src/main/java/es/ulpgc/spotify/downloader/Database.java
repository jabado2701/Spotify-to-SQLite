package es.ulpgc.spotify.downloader;

import com.google.gson.JsonObject;

import java.sql.*;

public class Database {
    public Database() {
        try (Connection conn = connect()) {
            Statement statement = conn.createStatement();
            createArtist(statement);
            createAlbums(statement);
            createTracks(statement);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
    }

    public void createArtist(Statement statement) throws SQLException {
        statement.execute("CREATE TABLE IF NOT EXISTS artists (" +
                "name TEXT, " +
                "id TEXT PRIMARY KEY, " +
                "type TEXT, " +
                "popularity TEXT, " +
                "followers TEXT" +
                ")");
    }

    public void createAlbums(Statement statement) throws SQLException {
        statement.execute("CREATE TABLE IF NOT EXISTS albums (" +
                "name TEXT, " +
                "id TEXT PRIMARY KEY, " +
                "release_date TEXT, " +
                "total_tracks TEXT" +
                ")");
    }

    public void createTracks(Statement statement) throws SQLException {
        statement.execute("CREATE TABLE IF NOT EXISTS tracks (" +
                "name TEXT, " +
                "id TEXT PRIMARY KEY, " +
                "explicit TEXT, " +
                "popularity TEXT, " +
                "duration_ms TEXT" +
                ")");
    }

    public void insertArtist(JsonObject artistObject, Integer followers) {
        String sql = "INSERT INTO artists(name,id,type,popularity,followers) VALUES(?,?,?,?,?) " +
                "ON CONFLICT(id) DO UPDATE SET name = ?, type = ?, popularity = ?, followers = ? WHERE id = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, artistObject.get("name").getAsString());
            pstmt.setString(2, artistObject.get("id").getAsString());
            pstmt.setString(3, artistObject.get("type").getAsString());
            pstmt.setString(4, artistObject.get("popularity").getAsString());
            pstmt.setInt(5, followers);
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void insertAlbums(JsonObject albumItemObject) {
        String sql = "INSERT INTO albums(name,id,release_date,total_tracks) VALUES(?,?,?,?) " +
                "ON CONFLICT(id) DO UPDATE SET name = ?, release_date = ?, total_tracks = ? WHERE id = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, albumItemObject.get("name").getAsString());
            pstmt.setString(2, albumItemObject.get("id").getAsString());
            pstmt.setString(3, albumItemObject.get("release_date").getAsString());
            pstmt.setString(4, albumItemObject.get("total_tracks").getAsString());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public void insertTracks(JsonObject songInfo) {
        String sql = "INSERT INTO tracks(name,id,explicit,popularity,duration_ms) VALUES(?,?,?,?,?) " +
                "ON CONFLICT(id) DO UPDATE SET name = ?, explicit = ?, popularity = ?, duration_ms = ? WHERE id = ?";
        try (Connection conn = connect();
             PreparedStatement pstmt = conn.prepareStatement(sql)) {
            pstmt.setString(1, songInfo.get("name").getAsString());
            pstmt.setString(2, songInfo.get("id").getAsString());
            pstmt.setString(3, songInfo.get("explicit").getAsString());
            pstmt.setString(4, songInfo.get("popularity").getAsString());
            pstmt.setString(5, songInfo.get("duration_ms").getAsString());
            pstmt.executeUpdate();
        } catch (SQLException e) {
            System.out.println(e.getMessage());
        }
    }

    public Connection connect() {
        Connection conn;
        try {
            String url = "jdbc:sqlite:database.db";
            conn = DriverManager.getConnection(url);
        } catch (SQLException e) {
            throw new RuntimeException(e);
        }
        return conn;
    }
}