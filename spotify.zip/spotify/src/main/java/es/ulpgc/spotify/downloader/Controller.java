package es.ulpgc.spotify.downloader;

import java.util.Scanner;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;

public class Controller {
    private final GetFunctions call = new GetFunctions();

    public Controller() throws Exception {
    }

    static List<String> artistList = new ArrayList<>();
    static List<String> albumList = new ArrayList<>();
    static List<String> trackList = new ArrayList<>();
    HashMap<String, String> artists = new HashMap<>() {{
        put("0TnOYISbd1XYRBk9myaseg", "pitbull");
        put("2wY79sveU1sp5g7SokKOiI", "sam_smith");
        put("6eUKZXaKkcviH0Ku9w2n3V", "ed_sheeran");
        put("0EmeFodog0BfCgMzAIvKQp", "shakira");
        put("3fMbdgg4jU18AjLCKBhRSm", "michael_jackson");
        System.out.println("WELCOME");
        Scanner read = new Scanner(System.in);
        System.out.println("Press number 1 EVERYTIME you want to introduce a singer id");
        System.out.println("Press number 2 if you want to make the database and exit");
        while (true) {
            int flag = read.nextInt();
            if (flag == 1) {
                System.out.println("Option 1 selected");
                System.out.println("Enter the singer id");
                String idSinger = read.next();
                put(idSinger, "");
                System.out.println("\nPress number 1 EVERYTIME you want to introduce a singer id");
                System.out.println("Press number 2 if you want to make the database and exit");
            } else if (flag == 2) {
                System.out.println("Option 2 selected");
                System.out.println("System running");
                break;
            } else {
                System.out.println("ERROR!");
                System.out.println("There is no function related to the introduced number\n");
                System.out.println("Closing program");
                System.exit(0);
            }
        }
    }};

    public void callCenter() throws Exception {
        int counter = 0;
        call.getArtists(counter, artists, artistList);
        call.getAlbums(counter, artistList, albumList);
        call.getTracks(counter, albumList, trackList);
        call.getTracksInfo(counter, trackList);
    }
}
