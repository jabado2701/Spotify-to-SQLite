package es.ulpgc.spotify.downloader;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import java.util.List;
import java.util.Map;

public class GetFunctions {
    SpotifyAccessor access = new SpotifyAccessor();

    public GetFunctions() throws Exception {
    }

    public void getArtists(int counter, Map<String, String> artists, List<String> artistList) throws Exception {
        for (String id : artists.keySet()) {
            String spotifyArtists = access.get("/artists/" + id, Map.of());
            counter++;
            if (counter % 100 == 0) Thread.sleep(4000);
            JsonObject getArtist = JsonParser.parseString(spotifyArtists).getAsJsonObject();
            artistList.add(getArtist.get("id").getAsString());
            JsonObject getFollowers = getArtist.get("followers").getAsJsonObject();
            Integer databaseFollowers = getFollowers.get("total").getAsInt();
            new Database().insertArtist(getArtist, databaseFollowers);
        }
    }

    public void getAlbums(int counter, List<String> artistList, List<String> albumList) throws Exception {
        for (String artist : artistList) {
            String spotifyAlbums = access.get("/artists/" + artist + "/albums", Map.of());
            counter++;
            if (counter % 100 == 0) Thread.sleep(4000);
            JsonObject getAlbumObject = JsonParser.parseString(spotifyAlbums).getAsJsonObject();
            JsonArray arrayOfAlbum = getAlbumObject.get("items").getAsJsonArray();
            for (JsonElement albumItem : arrayOfAlbum) {
                JsonObject getAlbumItem = albumItem.getAsJsonObject();
                albumList.add(getAlbumItem.get("id").getAsString());
                new Database().insertAlbums(getAlbumItem);
            }
        }
    }

    public void getTracks(int counter, List<String> albumList, List<String> trackList) throws Exception {
        for (String album : albumList) {
            String spotifyTracks = access.get("/albums/" + album + "/tracks", Map.of());
            counter++;
            if (counter % 100 == 0) Thread.sleep(4000);
            JsonObject getTrack = JsonParser.parseString(spotifyTracks).getAsJsonObject();
            JsonArray arrayOfTracks = getTrack.get("items").getAsJsonArray();
            for (JsonElement trackItemsElement : arrayOfTracks) {
                JsonObject trackItemsObject = trackItemsElement.getAsJsonObject();
                trackList.add(trackItemsObject.get("id").getAsString());
            }
        }
    }

    public void getTracksInfo(int counter, List<String> trackList) throws Exception {
        for (String songs : trackList) {
            String spotifySong = access.get("/tracks/" + songs, Map.of());
            counter++;
            if (counter % 100 == 0) Thread.sleep(4000);
            JsonObject databaseSong = JsonParser.parseString(spotifySong).getAsJsonObject();
            new Database().insertTracks(databaseSong);
        }
    }
}