package es.ulpgc.spotify.downloader;

public class Main {
    public static void main(String[] args) throws Exception {
        new Controller().callCenter();
    }
}